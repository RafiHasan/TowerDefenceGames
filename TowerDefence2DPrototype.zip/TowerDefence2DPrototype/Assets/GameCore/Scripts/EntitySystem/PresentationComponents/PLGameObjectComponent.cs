using Unity.Entities;
using UnityEngine;

public class PLGameObjectComponent : IComponentData
{
    public GameObject gameObject;
}
