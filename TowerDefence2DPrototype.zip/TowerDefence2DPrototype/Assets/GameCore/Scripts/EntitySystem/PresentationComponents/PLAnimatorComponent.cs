using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

public class PLAnimatorComponent : IComponentData
{
    public Animator animator;
}
