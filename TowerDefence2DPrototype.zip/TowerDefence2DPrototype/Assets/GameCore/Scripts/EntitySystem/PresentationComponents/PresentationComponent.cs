using Unity.Entities;
using UnityEngine;

public class PresentationComponent : IComponentData
{
    public GameObject Prefab;
}
