using Unity.Entities;
using UnityEngine;

public class PresentationObjectComponent : IComponentData
{
    public Sprite itemsprite;
}
