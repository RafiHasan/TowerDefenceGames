using Unity.Entities;
using UnityEngine;

public class PresentationTransformComponent : IComponentData
{
    public Transform transform;
}
