using Unity.Entities;
using UnityEngine;

public class PLTransformComponent : IComponentData
{
    public Transform transform;
}
