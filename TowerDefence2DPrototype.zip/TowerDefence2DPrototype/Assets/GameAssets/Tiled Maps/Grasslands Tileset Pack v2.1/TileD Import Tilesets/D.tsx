<?xml version="1.0" encoding="UTF-8"?>
<tileset name="D" tilewidth="16" tileheight="16" tilecount="256" columns="15">
 <image source="../D.png" width="256" height="256"/>
</tileset>
